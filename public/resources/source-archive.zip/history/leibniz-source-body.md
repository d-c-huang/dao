**XXI.**

**Explication de l'arithmétique binaire,  
qui se sert des seuls caractères 0 et 1, avec des  
remarques sur son utilité, et sur ce qu'elle donne  
le sens des anciennes figures chinoises de [Fohy](https://fr.wikipedia.org/wiki/fr:Fuxi "w:fr:Fuxi")** .

Le calcul ordinaire d’Arithmétique se fait suivant la progression de dix en dix. On se sert de dix caractères, qui sont
0, 1, 2, 3, 4, 5, 6, 7, 8, 9, qui signifient zéro, un et les nombres
suivans jusqu’à neuf inclusivement. Et puis allant à dix, on recommence, et on écrit dix par 10, et dix fois dix ou cent par
100, et dix fois cent ou mille par 1000, et dix fois mille par
10000, et ainsi de suite.

Mais au lieu de la progression de dix en dix, j’ai employé depuis plusieurs années la progression la plus simple de toutes, qui
va de deux en deux, ayant trouvé qu’elle sert à la perfection de la science des Nombres. Ainsi je n’y employé
point d’autres caractères que 0 et 1, et
puis allant à deux, je recommence. C’est
pourquoi deux s’écrit ici par 10, et deux fois
deux ou quatre par 100, et deux fois quatre ou huit par 1000, et deux fois huit ou
seize par 10000, et ainsi de suite. Voici la
Table des Nombres de cette façon, qu’on peut
continuer tant que l’on voudra.

[ [Voir cette Table des Nombres en image ici](https://upload.wikimedia.org/wikisource/fr/thumb/6/6c/Leibniz-en.francais-Gerhardt.Math.1a7.djvu/page529-1024px-Leibniz-en.francais-Gerhardt.Math.1a7.djvu.jpg) ]

On voit ici d’un coup d’oeil la raison d’une _propriété célèbre de la progression Géométrique double_ en Nombres entiers,
qui porte que si on n’a qu’un de ces nombres
de chaque degré, on en peut composer tous
les autres nombres entiers au dessous du double du plus haut degré. Car ici, c’est comme
si ou disait par exemple, que 111 ou 7 est la somme de
quatre, de deux et un, et que
1101 ou 13 est la somme de
huit, quatre et un. Cette
propriété sert aux Essayeurs
pour peser toutes sortes de
masses avec peu de poids et
pourroit servir dans les monnoyes pour
donner plusieurs valeurs avec peu de pièces.

Cette expressions des Nombres étant établie, sert à faire très
facilement toutes sortes d’opérations.

[ [Voir exemples pour l'Addition et la Soustraction en bas de l'image](https://upload.wikimedia.org/wikisource/fr/thumb/6/6c/Leibniz-en.francais-Gerhardt.Math.1a7.djvu/page529-1024px-Leibniz-en.francais-Gerhardt.Math.1a7.djvu.jpg) ]

[ [Voir exemples pour la Multiplication et pour la Division en image](https://upload.wikimedia.org/wikisource/fr/thumb/6/6c/Leibniz-en.francais-Gerhardt.Math.1a7.djvu/page530-1024px-Leibniz-en.francais-Gerhardt.Math.1a7.djvu.jpg) ]

Et toutes ces opérations sont si aisées, qu’on n’a jamais besoin de rien essayer ni deviner, comme il faut faire dans la division ordinaire. On n’a point besoin non plus de rien apprendre
par coeur ici, comme il faut faire dans le calcul ordinaire, où il
faut, savoir, par exemple, que 6 et 7 pris ensemble font 13, et que
5 multiplié par 3 donne 15, suivant la Table d’une fois un est
un, qu’on appelle Pythagorique. Mais ici tout cela se trouve et
se prouve de source, comme l’on voit dans les exemples précédens
sous les signes **☽** et .

Cependant je ne recommande point cette manière de compter, pour la faire introduire à la place de la pratique ordinaire
par dix. Car outre qu’on est accoutumé à celle-ci, on n’y a point
besoin d’y apprendre ce qu’on a déjà appris par coeur : ainsi la
pratique par dix est plus abrégée, et les nombres y sont moins
longs. Et si on étoit accoutumé à aller par douze ou par seize,
il y auroit encore plus d’avantage. Mais le calcul par deux, c’est-à-dire par 0 et par 1, en récompense de sa longueur, est le plus
fondamental pour la science, et donne de nouvelles découvertes,
qui se trouvent utiles ensuite, même pour la pratique des nombres,
et surtout pour la Géométrie, dont la raison est que les nombres
étant réduits aux plus simples principes, comme 0 et 1, il paroit
partout un ordre merveilleux. Pour exemple, dans la _Table_ même des Nombres _, on voit en chaque colonne régner des_ périodes qui recommencent toujours. Dans la première colonne
c’est 01, dans la seconde 0011, dans la troisième 00001111,
dans la quatrième 0000000011111111, et ainsi de suite. Et on
a mis de petits zéros dans la Table pour remplir le vuide au commencement de la colonne, et pour mieux marquer ces périodes.
On a mené aussi des lignes dans la Table, qui marquent que ce
que ces lignes renferment revient toujours sous elles. Et il se
trouve encore que les Nombres Quarrés, Cubiques et d’autres puis sances, item les Nombres Triangulaires, Pyramidaux et d’autres nombres figurés, ont aussi de semblables périodes, de sorte qu’on en
peut écrire les Tables tout de suite, sans calculer. Et une prolixité dans le commencement, qui donne ensuite le moyen d’epargner le calcul et d’aller à l’infini par règle, est infiniment avantageuse.

Ce qu’il y a de surprenant dans ce calcul, c’est que cette
Arithmétique par 0 et 1 se trouve contenir le mystère des lignes
d’un ancien Roi et Philosophe nommé Fohy, qu’on croit avoir vécu
il y a plus de quatre mille ans et que les Chinois regardent comme
le Fondateur de leur Empire et de leurs sciences. Il y a plusieurs
figures linéaires qu’on lui attribue, elles reviennent toutes à cette
Arithmétique ; mais il suffit de mettre ici _la Figure de huit Cova_ comme on l’appelle, qui passe pour fondamentale, et d’y
joindre l’explication qui est manifeste, pourvu qu’on remarque premièrement qu’une ligne entière — signifie l’unité ou 1, et secondement qu’une ligne brisée - - signifie le zéro ou 0.

`¦¦¦   |   000   |       0   |   0   |  
¦¦|   |   001   |       1   |   1   |  
¦|¦   |   010   |     10   |   3   |  
¦||   |   011   |     11   |   3   |  
|¦¦   |   100   |   100   |   4   |  
|¦|   |   101   |   101   |   5   |  
||¦   |   110   |   110   |   6   |  
|||   |   111   |   111   |   7   |`

Les Chinois ont perdu la signification des _Cova_ ou Lineations de _Fohy_ , peut-être depuis plus d’un millénaire d’années, et ils ont
fait des Commentaires la-dessus, où ils ont cherché je ne sçai
quels sens éloignés, de sorte qu’il a fallu que la vraie explication
leur vint maintenant des Européens. Voici comment : Il n’y a guères plus de deux ans que j’envoyai au R. P. Bouvet, Jésuite Français célèbre, qui demeure à Pékin, ma manière de compter par 0
et 1, et il n’en fallut pas davantage pour lui faire reconnaître que
c’est la clef des figures de Fohy. Ainsi m’écrivant le 14 Novembre 1701, il m’a envoyé la grande figure de ce Prince Philosophe
qui va à 64, et ne laisse plus lieu de douter de la vérité de notre
interprétation, de sorte qu’on peut dire que ce Père a déchiffré
l’enigme de Fohy, à l’aide de ce que je lui avois communiqué. Et
comme ces figures sont peut-être le plus ancien monument de science qui soit au monde, cette restitution de leur sens, après un
si grand intervalle de tems, paroitra d’autant plus curieuse.

Le consentement des figures de Foby et ma Table des
Nombres se fait mieux voir, lorsque dans la Table on supplée
les zéros initiaux, qui paroissent superflus, mais qui servent à mieux marquer la période de la colonne, comme je les y
ai supplées en effet avec des petits ronds pour les distinguer des
zéros nécessaires, et cet accord me donne un grande opinion de
la profondeur des méditations de Fohy. Car ce qui nous paroit
aisé maintenant, ne l’étoit pas tout dans ces tems éloignés. L’Arithmétique Binaire ou Dyadique est en effet fort aisée aujourd’hui,
pour peu qu’on y pense, parce que notre manière de compter y
aide beaucoup, dont il semble qu’on retranche seulement le trop.
Mais cette Arithmétique ordinaire pour dix ne paroit pas fort ancienne, au moins les Grecs et les Romains l’ont ignorée et ont été
privés de ses avantages. Il semble que l’Europe en doit l’introduction à Gerbert, depuis Pape sous le nom de Sylvestre II, qui
l’a eue des Maures d’Espagne.

Or comme l’on croit à la Chine que Fohy est encore auteur
des caractères Chinois, quoique fort altérés par la suite des tems ;
son essai d’Arithmétique fait juger qu’il pourroit bien s’y trouver
encore quelque chose de considérable par rapport aux nombres et
aux idées, si l'on pouvoit déterrer le fondement de l’écriture Chinoise, d’autant plus qu’on croit à la Chine, qu’il a eu égard aux
nombres en l’établissant. Le R. P. Bouvet est fort porté à pousser cette pointe, et très capable d’y réussir en bien des manières.
Cependant je ne sçai s’il y a jamais eu dans l’écriture Chinoise un
avantage approchant de celui qui doit être nécessairement dans une
Caractéristique que je projette. C’est que touL raisonnement
qu’on peut tirer des notions, pourroit être tiré de leurs Caractères
par une manière de calcul, qui seroit un des plus importans moyens d’aider l’esprit humain.